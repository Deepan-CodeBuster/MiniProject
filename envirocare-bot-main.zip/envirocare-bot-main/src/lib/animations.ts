
export const fadeIn = (delay: number = 0) => ({
  initial: { opacity: 0 },
  animate: { opacity: 1 },
  transition: { 
    duration: 0.5, 
    delay: delay,
    ease: 'easeInOut',
  }
});

export const slideUp = (delay: number = 0) => ({
  initial: { y: 20, opacity: 0 },
  animate: { y: 0, opacity: 1 },
  transition: { 
    duration: 0.5, 
    delay: delay,
    ease: 'easeOut',
  }
});

export const slideRight = (delay: number = 0) => ({
  initial: { x: -20, opacity: 0 },
  animate: { x: 0, opacity: 1 },
  transition: { 
    duration: 0.5, 
    delay: delay,
    ease: 'easeOut',
  }
});

export const staggerChildren = (staggerTime: number = 0.1) => ({
  animate: {
    transition: {
      staggerChildren: staggerTime,
    }
  }
});
