
import React, { useEffect } from 'react';
import NavBar from '@/components/NavBar';
import Hero from '@/components/Hero';
import EnvironmentData from '@/components/EnvironmentData';
import HealthPrediction from '@/components/HealthPrediction';
import NotificationPanel from '@/components/NotificationPanel';
import Dashboard from '@/components/Dashboard';

const Index = () => {
  // Smooth scroll to anchor links
  useEffect(() => {
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'A' && target.getAttribute('href')?.startsWith('#')) {
        e.preventDefault();
        const id = target.getAttribute('href')?.substring(1);
        const element = document.getElementById(id || '');
        if (element) {
          window.scrollTo({
            top: element.offsetTop - 80, // Offset for fixed header
            behavior: 'smooth',
          });
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);
    return () => document.removeEventListener('click', handleAnchorClick);
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <NavBar />
      <main className="flex-grow">
        <Hero />
        <EnvironmentData />
        <HealthPrediction />
        <NotificationPanel />
        <Dashboard />
      </main>
      <footer className="bg-gray-100 dark:bg-gray-900">
        <div className="container mx-auto py-8 px-6">
          <div className="text-center text-sm text-gray-500 dark:text-gray-400">
            <p>© 2023 HealthPredict AI. All rights reserved.</p>
            <p className="mt-2">Designed with precision and care.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
