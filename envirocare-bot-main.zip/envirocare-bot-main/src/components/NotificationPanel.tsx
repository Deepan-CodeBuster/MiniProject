
import React, { useState } from 'react';
import { BlurContainer } from './ui/blur-container';
import { cn } from '@/lib/utils';
import { Bell, Smartphone, Mail, MessageSquare, Clock, Filter } from 'lucide-react';

interface NotificationPanelProps {
  className?: string;
}

const notificationChannels = [
  { id: 'mobile', name: 'Mobile App', icon: <Smartphone className="h-5 w-5" />, enabled: true },
  { id: 'email', name: 'Email', icon: <Mail className="h-5 w-5" />, enabled: true },
  { id: 'sms', name: 'SMS', icon: <MessageSquare className="h-5 w-5" />, enabled: false },
];

const riskLevels = [
  { id: 'low', name: 'Low Risk', color: 'bg-health-low' },
  { id: 'medium', name: 'Medium Risk', color: 'bg-health-medium' },
  { id: 'high', name: 'High Risk', color: 'bg-health-high' },
];

const timeframes = [
  { id: '15min', name: '15 minutes' },
  { id: '30min', name: '30 minutes' },
  { id: '1hour', name: '1 hour' },
  { id: '3hours', name: '3 hours' },
  { id: '6hours', name: '6 hours' },
];

const NotificationPanel: React.FC<NotificationPanelProps> = ({ className }) => {
  const [selectedRisks, setSelectedRisks] = useState<string[]>(['medium', 'high']);
  const [channels, setChannels] = useState(notificationChannels);
  const [selectedTimeframe, setSelectedTimeframe] = useState('1hour');

  const toggleChannel = (id: string) => {
    setChannels(channels.map(channel => 
      channel.id === id ? { ...channel, enabled: !channel.enabled } : channel
    ));
  };

  const toggleRisk = (id: string) => {
    if (selectedRisks.includes(id)) {
      setSelectedRisks(selectedRisks.filter(risk => risk !== id));
    } else {
      setSelectedRisks([...selectedRisks, id]);
    }
  };

  return (
    <section id="notifications" className={cn('py-20 px-6', className)}>
      <div className="container mx-auto max-w-screen-xl">
        <div className="text-center mb-12 max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-slide-up">Smart Notifications</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Customize how and when you receive health risk notifications.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-3 animate-slide-up" style={{ animationDelay: '0.2s' }}>
            <BlurContainer className="p-6 h-full">
              <div className="flex items-center mb-6">
                <Bell className="h-6 w-6 text-primary mr-3" />
                <h3 className="text-xl font-semibold">Notification Channels</h3>
              </div>
              
              <div className="space-y-4">
                {channels.map(channel => (
                  <div key={channel.id} className="flex items-center justify-between p-4 rounded-lg border border-gray-100 dark:border-gray-800">
                    <div className="flex items-center">
                      <div className="p-2 rounded-full bg-gray-100 dark:bg-gray-800 mr-3">
                        {channel.icon}
                      </div>
                      <div>
                        <div className="font-medium">{channel.name}</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          {channel.enabled ? 'Enabled' : 'Disabled'}
                        </div>
                      </div>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        className="sr-only peer" 
                        checked={channel.enabled}
                        onChange={() => toggleChannel(channel.id)}
                      />
                      <div className="w-11 h-6 bg-gray-200 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                    </label>
                  </div>
                ))}
              </div>
              
              <div className="mt-8">
                <div className="flex items-center mb-4">
                  <Filter className="h-5 w-5 text-primary mr-2" />
                  <h4 className="font-medium">Risk Level Thresholds</h4>
                </div>
                <div className="flex flex-wrap gap-2">
                  {riskLevels.map(risk => (
                    <button
                      key={risk.id}
                      className={cn(
                        "px-4 py-2 rounded-full text-sm font-medium border transition-colors",
                        selectedRisks.includes(risk.id) 
                          ? `${risk.color}/20 border-${risk.color}/30 text-${risk.color}`
                          : "bg-gray-100 dark:bg-gray-800 border-gray-200 dark:border-gray-700"
                      )}
                      onClick={() => toggleRisk(risk.id)}
                    >
                      {risk.name}
                    </button>
                  ))}
                </div>
              </div>
            </BlurContainer>
          </div>
          
          <div className="lg:col-span-2 animate-slide-up" style={{ animationDelay: '0.3s' }}>
            <BlurContainer className="p-6 h-full">
              <div className="flex items-center mb-6">
                <Clock className="h-6 w-6 text-primary mr-3" />
                <h3 className="text-xl font-semibold">Notification Timing</h3>
              </div>
              
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                How far in advance would you like to be notified about potential health risks?
              </p>
              
              <div className="space-y-3">
                {timeframes.map(time => (
                  <div 
                    key={time.id}
                    className={cn(
                      "p-4 rounded-lg border transition-colors cursor-pointer",
                      selectedTimeframe === time.id
                        ? "border-primary bg-primary/5"
                        : "border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800"
                    )}
                    onClick={() => setSelectedTimeframe(time.id)}
                  >
                    <div className="flex items-center justify-between">
                      <span>{time.name}</span>
                      <div className={cn(
                        "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                        selectedTimeframe === time.id
                          ? "border-primary"
                          : "border-gray-300 dark:border-gray-600"
                      )}>
                        {selectedTimeframe === time.id && (
                          <div className="w-3 h-3 rounded-full bg-primary" />
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              
              <button className="mt-8 bg-primary text-white w-full py-3 rounded-lg font-medium transition-all hover:bg-primary/90 active:scale-98">
                Save Preferences
              </button>
            </BlurContainer>
          </div>
        </div>
      </div>
    </section>
  );
};

export default NotificationPanel;
