
import React from 'react';
import { cn } from '@/lib/utils';

interface BlurContainerProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
  intensity?: 'low' | 'medium' | 'high';
}

export const BlurContainer = ({
  children,
  className,
  intensity = 'medium',
  ...props
}: BlurContainerProps) => {
  const blurIntensity = {
    low: 'backdrop-blur-sm',
    medium: 'backdrop-blur-md',
    high: 'backdrop-blur-lg',
  };

  return (
    <div
      className={cn(
        'rounded-lg border border-white/10 bg-white/10',
        blurIntensity[intensity],
        'transition-all duration-300',
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
};
