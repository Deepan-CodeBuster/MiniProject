
import React from 'react';
import { cn } from '@/lib/utils';
import { BlurContainer } from './blur-container';

interface FloatingCardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
  delay?: string;
}

export const FloatingCard = ({
  children,
  className,
  delay = '0s',
  ...props
}: FloatingCardProps) => {
  return (
    <BlurContainer
      className={cn(
        'animate-float',
        className
      )}
      style={{ animationDelay: delay }}
      {...props}
    >
      {children}
    </BlurContainer>
  );
};
