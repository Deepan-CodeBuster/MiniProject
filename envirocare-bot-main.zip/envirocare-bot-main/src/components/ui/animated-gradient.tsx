
import React from 'react';
import { cn } from '@/lib/utils';

interface AnimatedGradientProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
  colors?: string;
}

export const AnimatedGradient = ({
  children,
  className,
  colors = 'from-blue-500 via-indigo-400 to-cyan-300',
  ...props
}: AnimatedGradientProps) => {
  return (
    <div
      className={cn(
        'bg-gradient-to-r animate-gradient bg-[length:200%_200%]',
        colors,
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
};
