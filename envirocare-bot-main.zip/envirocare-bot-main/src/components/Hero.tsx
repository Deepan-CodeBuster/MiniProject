
import React from 'react';
import { ArrowRight } from 'lucide-react';
import { AnimatedGradient } from './ui/animated-gradient';
import { BlurContainer } from './ui/blur-container';
import { cn } from '@/lib/utils';

const Hero = () => {
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-6 overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-blue-200 rounded-full opacity-30 blur-3xl" />
        <div className="absolute top-1/3 -left-40 w-80 h-80 bg-cyan-200 rounded-full opacity-30 blur-3xl" />
        <div className="absolute -bottom-40 right-1/4 w-80 h-80 bg-indigo-200 rounded-full opacity-30 blur-3xl" />
      </div>
      
      <div className="container mx-auto relative z-10 max-w-screen-xl">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
          <div className="md:col-span-7 space-y-6 text-center md:text-left">
            <div className="inline-block animate-fade-in">
              <BlurContainer className="px-3 py-1 text-xs font-medium text-primary mb-6 inline-block">
                AI-Powered Health Monitoring
              </BlurContainer>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight animate-slide-up">
              Predict Health Risks from <br className="hidden md:block" />
              <span className="text-primary">Environmental Changes</span>
            </h1>
            
            <p className="text-lg text-gray-600 dark:text-gray-300 max-w-xl mx-auto md:mx-0 animate-slide-up" style={{ animationDelay: '0.1s' }}>
              Our advanced AI analyzes real-time environmental data to predict potential health risks and notify you before they affect your wellbeing.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <button className="bg-primary text-white px-6 py-3 rounded-full font-medium transition-all hover:bg-primary/90 hover:shadow-lg active:scale-95 flex items-center justify-center gap-2 group">
                Get Started
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </button>
              <button className="bg-white dark:bg-gray-800 px-6 py-3 rounded-full font-medium transition-all hover:bg-gray-50 dark:hover:bg-gray-700 shadow-sm border border-gray-200 dark:border-gray-700">
                Learn More
              </button>
            </div>
            
            <div className="pt-6 grid grid-cols-3 gap-4 max-w-lg mx-auto md:mx-0 animate-slide-up" style={{ animationDelay: '0.3s' }}>
              {[
                { label: "Accuracy", value: "99.8%" },
                { label: "Users", value: "100K+" },
                { label: "Predictions", value: "1M+" }
              ].map((stat, i) => (
                <div key={stat.label} className={cn(
                  "text-center p-3 rounded-lg",
                  i === 0 ? "animate-fade-in" : i === 1 ? "animate-fade-in" : "animate-fade-in"
                )} style={{ animationDelay: `${0.4 + i * 0.1}s` }}>
                  <div className="text-2xl font-bold">{stat.value}</div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="md:col-span-5 animate-slide-right" style={{ animationDelay: '0.3s' }}>
            <BlurContainer className="p-6 rounded-2xl overflow-hidden relative bg-white/30 dark:bg-black/30">
              <AnimatedGradient className="absolute -z-10 inset-0 opacity-10" />
              <div className="aspect-square rounded-xl overflow-hidden relative">
                <img 
                  src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                  alt="Health monitoring" 
                  className="w-full h-full object-cover rounded-xl" 
                />
                
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <BlurContainer className="p-4 text-center" intensity="high">
                    <div className="text-sm font-medium">Current Prediction</div>
                    <div className="flex justify-center gap-2 mt-2">
                      {['Low', 'Medium', 'High'].map((risk, i) => (
                        <div key={risk} className={cn(
                          "px-3 py-1 rounded-full text-xs font-medium",
                          i === 0 ? "bg-health-low/20 text-health-low border border-health-low/30" : 
                          i === 1 ? "bg-health-medium/10 text-health-medium/90 border border-health-medium/30" : 
                          "bg-health-high/10 text-health-high/90 border border-health-high/30"
                        )}>
                          {risk} Risk
                        </div>
                      ))}
                    </div>
                  </BlurContainer>
                </div>
              </div>
            </BlurContainer>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
