
import React, { useState, useEffect } from 'react';
import { BlurContainer } from './ui/blur-container';
import { cn } from '@/lib/utils';
import { Activity, Bell, Menu, X } from 'lucide-react';

const NavBar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  const navLinks = [
    { name: "Dashboard", href: "#dashboard" },
    { name: "Predictions", href: "#predictions" },
    { name: "Notifications", href: "#notifications" },
    { name: "About", href: "#about" }
  ];

  return (
    <header className={cn(
      'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
      scrolled ? 'py-2' : 'py-4'
    )}>
      <BlurContainer className={cn(
        'mx-auto px-6 flex items-center justify-between transition-all duration-300',
        scrolled ? 'bg-white/80 dark:bg-black/80' : 'bg-transparent'
      )}>
        <div className="flex items-center">
          <Activity className="h-6 w-6 text-primary mr-2" />
          <span className="font-semibold text-lg">HealthPredict</span>
        </div>

        {/* Desktop menu */}
        <nav className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a 
              key={link.name}
              href={link.href}
              className="text-sm font-medium transition-colors hover:text-primary"
            >
              {link.name}
            </a>
          ))}
        </nav>

        <div className="hidden md:flex items-center space-x-4">
          <button className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors">
            <Bell className="h-5 w-5" />
          </button>
          <button className="bg-primary text-white px-4 py-2 rounded-full text-sm font-medium transition-all hover:bg-primary/90 active:scale-95">
            Get Started
          </button>
        </div>

        {/* Mobile menu toggle */}
        <button 
          className="md:hidden p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </BlurContainer>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <BlurContainer className="md:hidden px-6 py-4 mt-2 mx-4 animate-fade-in">
          <nav className="flex flex-col space-y-4">
            {navLinks.map((link) => (
              <a 
                key={link.name}
                href={link.href}
                className="text-sm font-medium transition-colors hover:text-primary py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <button className="bg-primary text-white px-4 py-2 rounded-full text-sm font-medium transition-all hover:bg-primary/90 w-full mt-2">
              Get Started
            </button>
          </nav>
        </BlurContainer>
      )}
    </header>
  );
};

export default NavBar;
