
import React from 'react';
import { BlurContainer } from './ui/blur-container';
import { cn } from '@/lib/utils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Activity, TrendingUp, Clock, Users } from 'lucide-react';

interface DashboardProps {
  className?: string;
}

const mockWeeklyData = [
  { day: 'Mon', respiratory: 30, allergies: 40, heart: 20 },
  { day: 'Tue', respiratory: 40, allergies: 30, heart: 25 },
  { day: 'Wed', respiratory: 60, allergies: 45, heart: 30 },
  { day: 'Thu', respiratory: 70, allergies: 80, heart: 40 },
  { day: 'Fri', respiratory: 50, allergies: 65, heart: 35 },
  { day: 'Sat', respiratory: 30, allergies: 40, heart: 30 },
  { day: 'Sun', respiratory: 20, allergies: 30, heart: 25 },
];

const mockHourlyData = [
  { time: '6AM', aqi: 20 },
  { time: '8AM', aqi: 25 },
  { time: '10AM', aqi: 40 },
  { time: '12PM', aqi: 65 },
  { time: '2PM', aqi: 55 },
  { time: '4PM', aqi: 40 },
  { time: '6PM', aqi: 30 },
];

const Dashboard: React.FC<DashboardProps> = ({ className }) => {
  return (
    <section className={cn('py-20 px-6 bg-gray-50 dark:bg-gray-900', className)}>
      <div className="container mx-auto max-w-screen-xl">
        <div className="text-center mb-12 max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-slide-up">Health Insights Dashboard</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Track and visualize your personalized health risk data over time.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-6">
          {[
            { title: 'Average Risk Score', value: '32', icon: <Activity />, change: '+2.4%', color: 'text-health-low' },
            { title: 'Highest Risk Factor', value: 'Pollen', icon: <TrendingUp />, change: '+12%', color: 'text-health-medium' },
            { title: 'Predictions Made', value: '253', icon: <Clock />, change: '+18', color: 'text-blue-500' },
            { title: 'Similar Profiles', value: '1.2K', icon: <Users />, change: '+124', color: 'text-indigo-500' },
          ].map((stat, index) => (
            <BlurContainer 
              key={stat.title} 
              className="p-6 animate-slide-up"
              style={{ animationDelay: `${0.2 + index * 0.1}s` }}
            >
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{stat.title}</p>
                  <h3 className="text-2xl font-bold mt-1">{stat.value}</h3>
                </div>
                <div className="p-3 bg-gray-100 dark:bg-gray-800 rounded-full">
                  {stat.icon}
                </div>
              </div>
              <div className={cn("mt-4 text-sm font-medium", stat.color)}>
                {stat.change}
              </div>
            </BlurContainer>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <BlurContainer className="p-6 lg:col-span-2 animate-slide-up" style={{ animationDelay: '0.6s' }}>
            <h3 className="font-semibold mb-4">Weekly Health Risk Factors</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={mockWeeklyData}
                  margin={{ top: 20, right: 30, left: 0, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip 
                    contentStyle={{ 
                      borderRadius: '8px', 
                      border: 'none', 
                      boxShadow: '0 4px 12px rgba(0,0,0,0.1)' 
                    }} 
                  />
                  <Bar dataKey="respiratory" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="allergies" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="heart" fill="#ef4444" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </BlurContainer>

          <BlurContainer className="p-6 animate-slide-up" style={{ animationDelay: '0.7s' }}>
            <h3 className="font-semibold mb-4">Today's Air Quality Index</h3>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={mockHourlyData}
                  margin={{ top: 20, right: 10, left: 0, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip 
                    contentStyle={{ 
                      borderRadius: '8px', 
                      border: 'none', 
                      boxShadow: '0 4px 12px rgba(0,0,0,0.1)' 
                    }} 
                  />
                  <Line 
                    type="monotone" 
                    dataKey="aqi" 
                    stroke="#3b82f6" 
                    strokeWidth={2} 
                    dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                    activeDot={{ fill: '#3b82f6', strokeWidth: 0, r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </BlurContainer>
        </div>

        <div className="text-center mt-12 animate-slide-up" style={{ animationDelay: '0.8s' }}>
          <button className="bg-primary text-white px-6 py-3 rounded-full font-medium transition-all hover:bg-primary/90 hover:shadow-lg active:scale-95">
            View Detailed Reports
          </button>
        </div>
      </div>
    </section>
  );
};

export default Dashboard;
