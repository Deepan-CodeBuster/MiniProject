
import React from 'react';
import { BlurContainer } from './ui/blur-container';
import { FloatingCard } from './ui/floating-card';
import { cn } from '@/lib/utils';
import { Droplets, Thermometer, Wind, Leaf } from 'lucide-react';

interface EnvironmentDataProps {
  className?: string;
}

const mockData = {
  temperature: { value: 24, unit: '°C', status: 'normal' },
  humidity: { value: 65, unit: '%', status: 'elevated' },
  airQuality: { value: 35, unit: 'AQI', status: 'good' },
  pollen: { value: 120, unit: 'ppm', status: 'high' },
};

const statusColors = {
  good: 'text-health-low',
  normal: 'text-blue-500',
  elevated: 'text-health-medium',
  high: 'text-health-high',
};

const EnvironmentData: React.FC<EnvironmentDataProps> = ({ className }) => {
  return (
    <section id="dashboard" className={cn('py-20 px-6', className)}>
      <div className="container mx-auto max-w-screen-xl">
        <div className="text-center mb-12 max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-slide-up">Real-Time Environmental Monitoring</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Our sensors continuously monitor key environmental factors that may impact your health.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <DataCard 
            title="Temperature" 
            value={mockData.temperature.value} 
            unit={mockData.temperature.unit} 
            status={mockData.temperature.status} 
            icon={<Thermometer className="h-6 w-6" />}
            color="from-blue-400 to-cyan-300"
            delay="0s"
          />
          <DataCard 
            title="Humidity" 
            value={mockData.humidity.value} 
            unit={mockData.humidity.unit} 
            status={mockData.humidity.status} 
            icon={<Droplets className="h-6 w-6" />}
            color="from-cyan-400 to-blue-300"
            delay="0.1s"
          />
          <DataCard 
            title="Air Quality" 
            value={mockData.airQuality.value} 
            unit={mockData.airQuality.unit} 
            status={mockData.airQuality.status} 
            icon={<Wind className="h-6 w-6" />}
            color="from-indigo-400 to-purple-300"
            delay="0.2s"
          />
          <DataCard 
            title="Pollen Count" 
            value={mockData.pollen.value} 
            unit={mockData.pollen.unit} 
            status={mockData.pollen.status} 
            icon={<Leaf className="h-6 w-6" />}
            color="from-green-400 to-emerald-300"
            delay="0.3s"
          />
        </div>
      </div>
    </section>
  );
};

interface DataCardProps {
  title: string;
  value: number;
  unit: string;
  status: string;
  icon: React.ReactNode;
  color: string;
  delay: string;
}

const DataCard: React.FC<DataCardProps> = ({ title, value, unit, status, icon, color, delay }) => {
  return (
    <FloatingCard 
      className="p-6 h-full animate-slide-up" 
      delay={delay}
    >
      <div className="flex items-start justify-between mb-4">
        <h3 className="font-medium">{title}</h3>
        <div className={cn(
          "p-2 rounded-full bg-gradient-to-br",
          color
        )}>
          {icon}
        </div>
      </div>
      
      <div className="flex items-end space-x-2">
        <div className="text-3xl font-bold">{value}</div>
        <div className="text-gray-500 dark:text-gray-400 mb-1">{unit}</div>
      </div>
      
      <div className={cn(
        "mt-2 text-sm font-medium",
        statusColors[status as keyof typeof statusColors] || 'text-gray-500'
      )}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-100 dark:border-gray-800">
        <div className="text-sm text-gray-500 dark:text-gray-400">
          Last updated: 2 minutes ago
        </div>
      </div>
    </FloatingCard>
  );
};

export default EnvironmentData;
