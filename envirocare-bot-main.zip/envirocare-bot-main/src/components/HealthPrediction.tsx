
import React from 'react';
import { BlurContainer } from './ui/blur-container';
import { cn } from '@/lib/utils';
import { Heart, AlertTriangle, CheckCircle, Activity } from 'lucide-react';

interface HealthPredictionProps {
  className?: string;
}

const mockPredictions = [
  {
    title: 'Respiratory',
    risk: 'medium',
    description: 'Moderate pollen levels may cause mild respiratory issues.',
    timeframe: '3-6 hours',
    icon: <Activity className="h-5 w-5" />,
  },
  {
    title: 'Allergies',
    risk: 'high',
    description: 'High pollen count forecast may trigger severe allergic reactions.',
    timeframe: '1-3 hours',
    icon: <AlertTriangle className="h-5 w-5" />,
  },
  {
    title: 'Heart Health',
    risk: 'low',
    description: 'Current temperature and humidity are optimal for cardiovascular health.',
    timeframe: '12+ hours',
    icon: <Heart className="h-5 w-5" />,
  },
  {
    title: 'General Wellbeing',
    risk: 'low',
    description: 'Overall environmental conditions are favorable for your health profile.',
    timeframe: '24+ hours',
    icon: <CheckCircle className="h-5 w-5" />,
  },
];

const riskStyles = {
  low: {
    bg: 'bg-health-low/10',
    text: 'text-health-low',
    border: 'border-health-low/30',
    icon: 'text-health-low',
  },
  medium: {
    bg: 'bg-health-medium/10',
    text: 'text-health-medium',
    border: 'border-health-medium/30',
    icon: 'text-health-medium',
  },
  high: {
    bg: 'bg-health-high/10',
    text: 'text-health-high',
    border: 'border-health-high/30',
    icon: 'text-health-high',
  },
};

const HealthPrediction: React.FC<HealthPredictionProps> = ({ className }) => {
  return (
    <section id="predictions" className={cn('py-20 px-6 bg-gray-50 dark:bg-gray-900', className)}>
      <div className="container mx-auto max-w-screen-xl">
        <div className="text-center mb-12 max-w-2xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 animate-slide-up">AI Health Predictions</h2>
          <p className="text-lg text-gray-600 dark:text-gray-300 animate-slide-up" style={{ animationDelay: '0.1s' }}>
            Our AI analyzes environmental data to predict potential health risks before they affect you.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {mockPredictions.map((prediction, index) => (
            <PredictionCard 
              key={prediction.title}
              prediction={prediction}
              index={index}
            />
          ))}
        </div>

        <div className="mt-12 text-center animate-slide-up" style={{ animationDelay: '0.5s' }}>
          <button className="bg-primary text-white px-6 py-3 rounded-full font-medium transition-all hover:bg-primary/90 hover:shadow-lg active:scale-95">
            View All Predictions
          </button>
        </div>
      </div>
    </section>
  );
};

interface PredictionCardProps {
  prediction: {
    title: string;
    risk: string;
    description: string;
    timeframe: string;
    icon: React.ReactNode;
  };
  index: number;
}

const PredictionCard: React.FC<PredictionCardProps> = ({ prediction, index }) => {
  const { title, risk, description, timeframe, icon } = prediction;
  const styles = riskStyles[risk as keyof typeof riskStyles];

  return (
    <BlurContainer 
      className="p-6 animate-slide-up bg-white dark:bg-gray-800" 
      style={{ animationDelay: `${0.2 + index * 0.1}s` }}
    >
      <div className="flex justify-between items-start">
        <div className="flex items-center">
          <div className={cn(
            "p-2 rounded-full mr-3",
            styles.bg,
            styles.icon
          )}>
            {icon}
          </div>
          <h3 className="font-semibold text-lg">{title}</h3>
        </div>
        <div className={cn(
          "px-3 py-1 rounded-full text-xs font-medium",
          styles.bg,
          styles.text,
          styles.border
        )}>
          {risk.charAt(0).toUpperCase() + risk.slice(1)} Risk
        </div>
      </div>
      
      <p className="mt-4 text-gray-600 dark:text-gray-300">
        {description}
      </p>
      
      <div className="mt-6 pt-4 border-t border-gray-100 dark:border-gray-700 flex justify-between items-center">
        <div className="text-sm text-gray-500 dark:text-gray-400">
          Expected in: <span className="font-medium">{timeframe}</span>
        </div>
        <button className="text-primary text-sm font-medium hover:underline">
          View Details
        </button>
      </div>
    </BlurContainer>
  );
};

export default HealthPrediction;
